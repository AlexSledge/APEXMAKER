require "Items/Distributions"

--[[ Chinatown Items ]]
SuburbsDistributions.herb = {
	dishescabinet =
	{
		rolls = 1,
		items = {
			"Comfrey", 100,
			"ComfreyCataplasm", 100,
			"CommonMallow", 100,
			"Plantain", 100,
			"PlantainCataplasm", 100,
			"WildGarlic", 100,
			"WildGarlicCataplasm", 100,
			"HerbalistMag", 10,
		}
	},
}

SuburbsDistributions.hammer = {
	crate =
	{
		rolls = 1,
		items = {
			"BallPeenHammer", 100,
			"Hammer", 100,
			"Sledgehammer", 100,
			"Sledgehammer2", 100,
		}
	},
}

SuburbsDistributions.mingshi = {
	crate =
	{
		rolls = 5,
		items = {        
			"TVDinner", 85,
		}
	},
}

SuburbsDistributions.katana = {
	katana =
	{
		rolls = 2,
		items = {        
			"Katana", 100,
		}
	},
}

--[[ New Ekron Items ]]
SuburbsDistributions.growroom = {
	metal_shelves =
	{
		rolls = 1,
		items = {        
			"TheBong", 50, 
			"Greenfire.Cannabis", 100,
			"Greenfire.Cannabis", 100,
			"Greenfire.Cannabis", 100,                      
		}
	},
}

SuburbsDistributions.rusty = {
	metal_shelves =
	{
		rolls = 1,
		items = {        
			"Rusty", 100,                     
		}
	},
}

--[[ Pitstop Map Items]]
SuburbsDistributions.klean = {
	metal_shelves =
	{
		rolls = 1,
		items = {        
			"CleanUpKrewJumpsuit", 100,
			"KleanBackPack", 100,
			"Shoes_CleanUpKrewSneakers", 100,
		}
	},
}